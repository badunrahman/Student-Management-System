/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementsys2;

import java.util.ArrayList;

/**
 *
 * @author badunrahman
 */
public interface FileHandler {
    
    //here i am creating two method to save to file and load it from file
    
    //takes the file name and the student arraylist of objects
    
    void saveToFile(String fileName,ArrayList<Student>students);
    
    //2nd method
    
    ArrayList<Student>loadFromFile(String fileName);
    
    
    
}
