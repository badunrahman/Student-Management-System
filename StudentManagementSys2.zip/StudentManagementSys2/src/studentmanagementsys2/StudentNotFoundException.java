/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementsys2;

/**
 *
 * @author badunrahman
 */
public class StudentNotFoundException extends Exception {
    
    public StudentNotFoundException(){
        super();
    }
    
    public StudentNotFoundException(String message){
        super(message);
    }
}

