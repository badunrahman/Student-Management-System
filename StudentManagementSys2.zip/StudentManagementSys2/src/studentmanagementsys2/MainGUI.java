package studentmanagementsys2;



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author badunrahman
 */
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

public class MainGUI extends Application {

   // instance of StudentManager that handles all the logic operation
   private StudentManager manager = new StudentManager();
   // observablelist is used to see the real change in GUI automatically
    private ObservableList<Student> studentData = FXCollections.observableArrayList();

    @Override
    
    // entry point
    public void start(Stage primaryStage) {
        
        // setting the title in primary window
        primaryStage.setTitle("Student Management System");

        // creating UI components 
        // to take input from the user
        
        // for name 
        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();
        //for id
        Label idLabel = new Label("ID:");
        TextField idField = new TextField();
        //for GPA
        Label gpaLabel = new Label("GPA:");
        TextField gpaField = new TextField();

        
        // Acrion buttons to perform each task
        Button addButton = new Button("Add Student");
        Button deleteButton = new Button("Delete Student");
        Button searchButton = new Button("Search by ID");
        Button displayButton = new Button("Display All Students");
        Button saveButton = new Button("Save to File");
        Button loadButton = new Button("Load from File");
        Button exitButton = new Button("Exit");

        // creating Sorting Buttons to sort student by name,id,gpa
        Button sortByNameButton = new Button("Sort by Name");
        Button sortByIdButton = new Button("Sort by ID");
        Button sortByGpaButton = new Button("Sort by GPA");

        // display table of student records 
        TableView<Student> table = new TableView<>();
        

        // Define table columns
        // will show student object with string data type
        // will show the name attributes of each student
        TableColumn<Student, String> nameColumn = new TableColumn<>("Name");
        
        // sercellvaluefactory display data for each cell in the column
        // gets the student object from the current row and calls the getname method
        //and wraps the name in simplestringproperty to make it observable
        
        nameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));

        //same for id
        TableColumn<Student, Integer> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getID()).asObject());

        // same for gpa
        TableColumn<Student, Double> gpaColumn = new TableColumn<>("GPA");
        gpaColumn.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getGPA()).asObject());
        
        // adding defined columns in the tableview
        table.getColumns().addAll(nameColumn, idColumn, gpaColumn);
        //binding the tableView to observablelist
        // any change made will automatically reflect on the table view
        table.setItems(studentData);

        // Layout Setup

        // organizing the input fields
        GridPane inputGrid = new GridPane();
        // sets the horizontal gap between columns to pixels
        inputGrid.setHgap(10);
        //sets the vertical gap between row to pixels
        inputGrid.setVgap(10);

        // Align the labels and fields properly
        inputGrid.add(nameLabel, 0, 0);
        inputGrid.add(nameField, 1, 0);
        inputGrid.add(idLabel, 0, 1);
        inputGrid.add(idField, 1, 1);
        inputGrid.add(gpaLabel, 0, 2);
        inputGrid.add(gpaField, 1, 2);
        inputGrid.add(addButton, 12, 3);

        // Align Add button to the right
        GridPane.setHalignment(addButton, javafx.geometry.HPos.RIGHT);

        // HBox for Action Buttons (Delete, Search, Display, Save, Load, Exit)
        // creates a 10 pixels of spacing between each child node
        // 6 nodes added to the HBox
        // and centers the bottons 
        HBox actionButtonBox = new HBox(10, deleteButton, searchButton, displayButton, saveButton, loadButton, exitButton);
        actionButtonBox.setAlignment(Pos.CENTER);

        // HBox for Sorting Buttons
        HBox sortingButtonBox = new HBox(10, sortByNameButton, sortByIdButton, sortByGpaButton);
        sortingButtonBox.setAlignment(Pos.CENTER);

        // VBox for all components
        // vertically stacks all the main components
        VBox mainLayout = new VBox(20, inputGrid, actionButtonBox, sortingButtonBox, table);
        // adds padding of 20 pixels from each side
        //making sure that buttons are not agains the window edges
        mainLayout.setPadding(new Insets(20, 20, 20, 20));

        // Event Handling associating action with each buttons
        
        // action for the addButton
        
        addButton.setOnAction(e -> {
            
            // retrives the values from the textfields and trims any whitespaces
            
            String name = nameField.getText().trim();
            String idStr = idField.getText().trim();
            String gpaStr = gpaField.getText().trim();

            // simple input validation
            // if any fileds are empty sets out and error message
            
            if (name.isEmpty() || idStr.isEmpty() || gpaStr.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Input Error", "Please fill all fields.");
                return;
            }
            
            // try to parse idstr to integer
            // if fails means invalid input
            // sets out and error message
            int id;
            try {
                id = Integer.parseInt(idStr);

            } catch (NumberFormatException ex) {
                showAlert(Alert.AlertType.ERROR, "Input Error", "ID must be a numeric value.");
                return;
            }
            
            // same gets the string value and try to parse it
            // if successful then cheacks for gpa value if more than 5
            // and less than 0 shows an error message
            // 
            double gpa;
            try {
                gpa = Double.parseDouble(gpaStr);
                if (gpa < 0.0 || gpa > 5.0) {
                    showAlert(Alert.AlertType.ERROR, "Input Error", "GPA must be between 0.0 and 5.0.");
                    return;
                }
            } catch (NumberFormatException ex) {
                showAlert(Alert.AlertType.ERROR, "Input Error", "GPA must be a numeric value.");
                return;
            }
            
            //creats a new student object with the given info
            //call the manager to add student to the studentmanager
            //if successful adds the student to the observable list
            // which updates the tableview and sets out a message "student added successfullu"
            // if duplicate set out an error message
            

            Student student = new Student(name, id, gpa);
            boolean isAdded = manager.addStudent(student);
            if (isAdded) {
                studentData.add(student);
                showAlert(Alert.AlertType.INFORMATION, "Success", "Student added successfully.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Duplicate ID", "A student with this ID already exists.");
            }

            // Clear input fields
            nameField.clear();
            idField.clear();
            gpaField.clear();
        });
        
        
        // action for deleteButton

        deleteButton.setOnAction(e -> {
            
            // creating textinputdialog
            // sets the title to delete student
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Delete Student");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter Student ID to Delete:");
            //waits for the user input
            dialog.showAndWait().ifPresent(idStr -> {
                try {
                    //gets the id and calls the removestudent method
                    int id = Integer.parseInt(idStr.trim());
                    manager.removeStudnet(id);

                    studentData.removeIf(s -> s.getID() == id);
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Student removed successfully.");
                } catch (NumberFormatException ex) {
                    showAlert(Alert.AlertType.ERROR, "Input Error", "ID must be a numeric value.");
                } catch (StudentNotFoundException ex) {
                    showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage());
                }
            });
        });

        
        // action for searchButton
        
        searchButton.setOnAction(e -> {
            
            // same thing as delete button 
            // creating a dialog box asking for the student id to search
            
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Search Student");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter Student ID to Search:");
            
            dialog.showAndWait().ifPresent(idStr -> {
                try {
                    // trying to parse the id
                    int id = Integer.parseInt(idStr.trim());
                    // using the recursive method to search the student id
                    Student found = manager.searchStudentById(id);
                    // showing the info
                    //
                    showAlert(Alert.AlertType.INFORMATION, "Student Found", found.getDescription());
                } catch (NumberFormatException ex) {
                    showAlert(Alert.AlertType.ERROR, "Input Error", "ID must be a numeric value.");
                } catch (StudentNotFoundException ex) {
                    showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage());
                }
            });
        });

        
        // display all student in tableview
        // clears all the initial student fromt he observalbel list 
        // and adds all the student from the sudentsmanager by calling
        // getstudent method 
        // showing all the current list of student
        displayButton.setOnAction(e -> {
            studentData.clear();
            studentData.addAll(manager.getStudents());
        });

        
        // action for saveButton
        
        // saves the current list of student to a specified file
        saveButton.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog("students.txt");
            dialog.setTitle("Save to File");
            dialog.setHeaderText(null);
            // takes the name of the file 
            dialog.setContentText("Enter file name to save:");
            dialog.showAndWait().ifPresent(fileName -> {
                // calls the save file method from studentmanager
                // and saves the 
                manager.saveToFile(fileName, manager.getStudents());
                showAlert(Alert.AlertType.INFORMATION, "Save Successful", "Students saved to " + fileName + ".");
            });
        });

        
        //action for loadButtons 
        //
        loadButton.setOnAction(e -> {
            // creates default dilog box
            TextInputDialog dialog = new TextInputDialog("students.txt");
            dialog.setTitle("Load from File");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter file name to load:");
            // takes the file name
           
            dialog.showAndWait().ifPresent(fileName -> {
                // calls the loadFromFile from student manager
                
                manager.loadFromFile(fileName);
                // clear all the current data
                studentData.clear();
                // adds all the student to studentdata and update the tableview
                // loads a successful message
                studentData.addAll(manager.getStudents());
                showAlert(Alert.AlertType.INFORMATION, "Load Successful", "Students loaded from " + fileName + ".");
            });
        });

        // action for exitbutton
        //exits the system
        exitButton.setOnAction(e -> {
            primaryStage.close();
        });

        // action  for Sorting Buttons
        
        sortByNameButton.setOnAction(e -> {
            // calls the sortbyName method from the studentmanager
            // and calss trhe updateTableview which clears the current list of student
            // and refresh the tableview
            manager.sortByName();
            updateTableView();
        });

        // same way
        sortByIdButton.setOnAction(e -> {
            manager.sortById();
            updateTableView();
        });

        //same way
        sortByGpaButton.setOnAction(e -> {
            manager.sortByGpa();
            updateTableView();
        });

        // Final Scene Setup
        // displaying it on the primary stage
        // sets the width and height of the window 800 and 600
        // 
        Scene scene = new Scene(mainLayout, 800, 600);
        //assigning the new created scne to the primary stage
        primaryStage.setScene(scene);
        // making the primary stage visible
        primaryStage.show();
    }

    
    // Updates the TableView with the current list of students.

    private void updateTableView() {
        studentData.clear();
        studentData.addAll(manager.getStudents());
    }

    // method to display alert dialog to reuse
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        // takes the type
        Alert alert = new Alert(alertType);
        //the title
        alert.setTitle(title);
        // no header
        alert.setHeaderText(null);
        // takes the message
        alert.setContentText(message);
        // now wait
        alert.showAndWait();
    }
}