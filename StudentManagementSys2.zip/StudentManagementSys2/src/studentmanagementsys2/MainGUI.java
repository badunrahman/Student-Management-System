package studentmanagementsys2;



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author badunrahman
 */
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

public class MainGUI extends Application {

   
   private StudentManager manager = new StudentManager();
    private ObservableList<Student> studentData = FXCollections.observableArrayList();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Student Management System");

        // Creating UI components
        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();

        Label idLabel = new Label("ID:");
        TextField idField = new TextField();

        Label gpaLabel = new Label("GPA:");
        TextField gpaField = new TextField();

        Button addButton = new Button("Add Student");
        Button deleteButton = new Button("Delete Student");
        Button searchButton = new Button("Search by ID");
        Button displayButton = new Button("Display All Students");
        Button saveButton = new Button("Save to File");
        Button loadButton = new Button("Load from File");
        Button exitButton = new Button("Exit");

        // Create Sorting Buttons
        Button sortByNameButton = new Button("Sort by Name");
        Button sortByIdButton = new Button("Sort by ID");
        Button sortByGpaButton = new Button("Sort by GPA");

        TableView<Student> table = new TableView<>();
        // Define table columns
        TableColumn<Student, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));

        TableColumn<Student, Double> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getID()).asObject());

        TableColumn<Student, Double> gpaColumn = new TableColumn<>("GPA");
        gpaColumn.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getGPA()).asObject());

        table.getColumns().addAll(nameColumn, idColumn, gpaColumn);
        table.setItems(studentData);

        // Layout Setup

        // Input GridPane for Name, ID, GPA fields and Add button
        GridPane inputGrid = new GridPane();
        inputGrid.setHgap(10);
        inputGrid.setVgap(10);

        // Align the labels and fields properly
        inputGrid.add(nameLabel, 0, 0);
        inputGrid.add(nameField, 1, 0);
        inputGrid.add(idLabel, 0, 1);
        inputGrid.add(idField, 1, 1);
        inputGrid.add(gpaLabel, 0, 2);
        inputGrid.add(gpaField, 1, 2);
        inputGrid.add(addButton, 12, 3);

        // Align Add button to the right
        GridPane.setHalignment(addButton, javafx.geometry.HPos.RIGHT);

        // HBox for Action Buttons (Delete, Search, Display, Save, Load, Exit)
        HBox actionButtonBox = new HBox(10, deleteButton, searchButton, displayButton, saveButton, loadButton, exitButton);
        actionButtonBox.setAlignment(Pos.CENTER);

        // HBox for Sorting Buttons
        HBox sortingButtonBox = new HBox(10, sortByNameButton, sortByIdButton, sortByGpaButton);
        sortingButtonBox.setAlignment(Pos.CENTER);

        // VBox for all components
        VBox mainLayout = new VBox(20, inputGrid, actionButtonBox, sortingButtonBox, table);
        mainLayout.setPadding(new Insets(20, 20, 20, 20));

        // Event Handling
        addButton.setOnAction(e -> {
            String name = nameField.getText().trim();
            String idStr = idField.getText().trim();
            String gpaStr = gpaField.getText().trim();

            // Input Validation
            if (name.isEmpty() || idStr.isEmpty() || gpaStr.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Input Error", "Please fill all fields.");
                return;
            }

            int id;
            try {
                id = Integer.parseInt(idStr);

            } catch (NumberFormatException ex) {
                showAlert(Alert.AlertType.ERROR, "Input Error", "ID must be a numeric value.");
                return;
            }

            double gpa;
            try {
                gpa = Double.parseDouble(gpaStr);
                if (gpa < 0.0 || gpa > 4.0) {
                    showAlert(Alert.AlertType.ERROR, "Input Error", "GPA must be between 0.0 and 4.0.");
                    return;
                }
            } catch (NumberFormatException ex) {
                showAlert(Alert.AlertType.ERROR, "Input Error", "GPA must be a numeric value.");
                return;
            }

            Student student = new Student(name, id, gpa);
            boolean isAdded = manager.addStudent(student);
            if (isAdded) {
                studentData.add(student);
                showAlert(Alert.AlertType.INFORMATION, "Success", "Student added successfully.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Duplicate ID", "A student with this ID already exists.");
            }

            // Clear input fields
            nameField.clear();
            idField.clear();
            gpaField.clear();
        });

        deleteButton.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Delete Student");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter Student ID to Delete:");
            dialog.showAndWait().ifPresent(idStr -> {
                try {
                    int id = Integer.parseInt(idStr.trim());
                    manager.removeStudnet(id);

                    studentData.removeIf(s -> s.getID() == id);
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Student removed successfully.");
                } catch (NumberFormatException ex) {
                    showAlert(Alert.AlertType.ERROR, "Input Error", "ID must be a numeric value.");
                } catch (StudentNotFoundException ex) {
                    showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage());
                }
            });
        });

        searchButton.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Search Student");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter Student ID to Search:");
            dialog.showAndWait().ifPresent(idStr -> {
                try {
                    int id = Integer.parseInt(idStr.trim());
                    Student found = manager.searchStudentById(id);
                    showAlert(Alert.AlertType.INFORMATION, "Student Found", found.getDescription());
                } catch (NumberFormatException ex) {
                    showAlert(Alert.AlertType.ERROR, "Input Error", "ID must be a numeric value.");
                } catch (StudentNotFoundException ex) {
                    showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage());
                }
            });
        });

        displayButton.setOnAction(e -> {
            studentData.clear();
            studentData.addAll(manager.getStudents());
        });

        saveButton.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog("students.txt");
            dialog.setTitle("Save to File");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter file name to save:");
            dialog.showAndWait().ifPresent(fileName -> {
                manager.saveToFile(fileName, manager.getStudents());
                showAlert(Alert.AlertType.INFORMATION, "Save Successful", "Students saved to " + fileName + ".");
            });
        });

        loadButton.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog("students.txt");
            dialog.setTitle("Load from File");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter file name to load:");
            dialog.showAndWait().ifPresent(fileName -> {
                manager.loadFromFile(fileName);
                studentData.clear();
                studentData.addAll(manager.getStudents());
                showAlert(Alert.AlertType.INFORMATION, "Load Successful", "Students loaded from " + fileName + ".");
            });
        });

        exitButton.setOnAction(e -> {
            primaryStage.close();
        });

        // Event Handling for Sorting Buttons
        sortByNameButton.setOnAction(e -> {
            manager.sortByName();
            updateTableView();
        });

        sortByIdButton.setOnAction(e -> {
            manager.sortById();
            updateTableView();
        });

        sortByGpaButton.setOnAction(e -> {
            manager.sortByGpa();
            updateTableView();
        });

        // Final Scene Setup
        Scene scene = new Scene(mainLayout, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Updates the TableView with the current list of students.
     */
    private void updateTableView() {
        studentData.clear();
        studentData.addAll(manager.getStudents());
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}