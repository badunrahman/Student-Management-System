/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementsys2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author badunrahman
 */
public class StudentManager implements FileHandler {
    
    protected ArrayList<Student>students;
    
    public StudentManager(){
        students = new ArrayList<>();
    }
    
    
    // adds student to the list if the id in unique
    // use for each loop to go through the list with avliable ids and compare them
    //if no match found reutrn false and student is addedt to the list
   public boolean addStudent(Student student){
        for(Student s : students){
            if(s.getID() == student.getID()){
                System.out.println("A student with the same ID already exists: " + student.getID());
                return false;
            }
        }
        students.add(student);
        System.out.println("Student added successfully :)");
        return true;
    }
   
   
   //remove student by getting their id
 // if not found will thow exception 
    public void removeStudnet(int id) throws StudentNotFoundException {
        
        Student removeStudents = null;
        
        for(Student s:students){
            if(s.getID() == id){
                removeStudents = s;
                break;
            }
        }
        
        if(removeStudents !=null){
            students.remove(removeStudents);
            System.out.println("student with ID "+ id + "has been removed ");
        }else{
            throw new StudentNotFoundException("student with this id "+id +"had not been found in the system ");
        }
        
        
    }
    
    //display all student to the system
    
    public void displayStudents(){
        
        System.out.println("------list of students-------");
        for(Student s:students){
            System.out.println(s);
        }
    }
    
    
   // saving list of student to a specificed file name
    // with their name,id,gpa
    
   // using bufferedwriter to write to the file
    public void saveToFile(String fileName, ArrayList<Student> students){
        
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))){
            
            for(Student s : students){
                
                String line = s.getName() + "," + s.getID() + "," + s.getGPA();
                writer.write(line);
                writer.newLine();
            }
            
            System.out.println("Students have been saved to the file named: " + fileName);
            
        } catch(IOException e)
        {
            System.out.println("An error occurred while saving the file: " + e.getMessage());
        }
        
    }
    
    
    // readint the file using bufferedreader to read from the file
    // cheak for 3 parts and seperate them by commas
    // gets the name,id and gpa and creates a new student object and added to the list
    //
    
    @Override
    public ArrayList<Student> loadFromFile(String fileName){
        ArrayList<Student> loadedStudents = new ArrayList<>();
        
        try(BufferedReader reader = new BufferedReader(new FileReader(fileName))){
            
            String line;
            
            while((line = reader.readLine()) != null){
                
                String[] data = line.split(",");
                
                if(data.length == 3){
                    
                    String name = data[0].trim();
                    int id = Integer.parseInt(data[1].trim());
                    double gpa = Double.parseDouble(data[2].trim());
                    
                    // checks for duplicate ID before adding
                    boolean isAdded = addStudent(new Student(name, id, gpa));
                    if(isAdded){
                        loadedStudents.add(new Student(name, id, gpa));
                    } else {
                        System.out.println("Duplicate ID found while loading: " + id );
                    }
                }
            }
            System.out.println("Students have been loaded from the file named: " + fileName);
        } catch(IOException e){
            System.out.println("An error has occurred during the action: " + e.getMessage());
        } catch(NumberFormatException e){
            System.out.println("Data format error: " + e.getMessage());
        }
        return loadedStudents;
    }
    
    
    
      
      public ArrayList<Student> getStudents(){
          return students;
      }
      
    
     //searching student id with recursion 
      public Student searchStudentById(int id) throws StudentNotFoundException {
        return searchRecursive(id, 0);
    }

    
    // searchRecurisive method 
    private Student searchRecursive(int id, int index) throws StudentNotFoundException {
       
        if (index >= students.size()) {
            throw new StudentNotFoundException("Student with ID " + id + " not found.");
        }
        
        // retrivein the student in the current index
        Student current = students.get(index);
        
        // if they matches return student
        if (current.getID() == id) {
            return current;
        }
        
        // move to the next index
        return searchRecursive(id, index + 1);
    }
    
    
    // sorting method
    
    public void sortByName() {
        Collections.sort(students, Comparator.comparing(Student::getName));
        System.out.println("Students sorted by Name.");
    }

    public void sortById() {
        Collections.sort(students, Comparator.comparingInt(Student::getID));
        System.out.println("Students sorted by ID.");
    }

    public void sortByGpa() {
        Collections.sort(students, Comparator.comparingDouble(Student::getGPA).reversed());
        System.out.println("Students sorted by GPA (High to Low).");
    }
    
    
    
    
}
