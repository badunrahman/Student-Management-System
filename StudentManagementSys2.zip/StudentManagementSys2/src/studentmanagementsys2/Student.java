/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementsys2;

/**
 *
 * @author badunrahman
 */
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;

// student class inheriting from person class
public class Student extends Person {

    private int ID;
    private double GPA;
    
    
    //constructor
    
    public Student(String name,int ID,double GPA){
        super(name);
        this.ID=ID;
        this.GPA=GPA;
        
    }
    
    //getters and setters
    
    public int getID(){
        return ID;
    }
    
    public double getGPA(){
        return GPA;
    }
    
    public void setID(int ID){
        this.ID=ID;
    }
    
    public void setGPA(double GPA){
        this.GPA=GPA;
    }
    
    
    // provided description of students
    @Override
    public String getDescription(){
        return "name :"+this.getName()+" ID :"+this.getID()+" GPA: "+this.getGPA();
    }
    
    // overrride the tostring method to return student description
    
    @Override
    public String toString(){
        return getDescription();
    }
    

    
    
    
    
}
