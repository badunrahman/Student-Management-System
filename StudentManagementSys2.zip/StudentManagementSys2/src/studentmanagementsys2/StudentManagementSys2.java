/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagementsys2;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.stage.Stage;

/**
 *
 * @author badunrahman
 */

//------------------------------------------------------
//Final Project 0.2
//Written by Badun Rahman--2330975
//programing2 ----002 --Fall 2024
//-------------------------------------------------------
public class StudentManagementSys2 extends Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
          launch(args);
        
    }
    
    public void start(Stage primaryStage){
        MainGUI mainGui = new MainGUI();
        try{
            mainGui.start(primaryStage);
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
    
}
